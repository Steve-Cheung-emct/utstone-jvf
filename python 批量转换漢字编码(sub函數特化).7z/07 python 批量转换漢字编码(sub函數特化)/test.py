#!/usr/bin/env python3
# -*- encoding -*-
#-*- coding:utf-8 -*-
import io
import sys
import urllib.request
#改變標準輸出的默認編碼為utf8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8') 
from collections import Counter

# %% 将 Adobe Japan 1-6 漢字存放于 sh0.tex 中，
# %% 将 BMP 漢字存放于 sh1.tex 中，
# %% 运行run.bat 得到格式化后的文本

# %% 将两个集合的漢字合起来，求频次，频次为1的将被输出到格式化的文本

a = [x for x in open(r"./sh0.tex", "r", encoding="utf-8").read() if  19968<=ord(x)<=40943  or 13312<=ord(x)<=19893 ]
b = [x for x in open(r"./sh1.tex", "r", encoding="utf-8").read() if  19968<=ord(x)<=40943  or 13312<=ord(x)<=19893 ]

all = a + a + b

c = Counter(all)

for x in c:
    if c[x] == 1:
        print("(CHARACTER H "+ str.upper(hex(ord(x))) )
        print("    (MAP")
        print("      (SPECIAL ps: gsave currentpoint currentpoint translate 1 0.96 scale neg exch neg exch translate)")
        print("      (SELECTFONT D 3)")
        print("      (SETCHAR H " + str.upper(hex(ord(x))) + ")")
        print("      (SPECIAL ps: currentpoint grestore moveto)")
        print("      )")
        print("    )")



