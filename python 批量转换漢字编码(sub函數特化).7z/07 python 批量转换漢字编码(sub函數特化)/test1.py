#!/usr/bin/env python3
# -*- encoding -*-
#-*- coding:utf-8 -*-
import io
import sys
import urllib.request
#改變標準輸出的默認編碼為utf8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8') 

#%%
import os
import glob
import re


#%%
def mysub(mytext):
    mytext = mytext.replace("：","︰")
# 在此處添加自定義規則，注意python的縮進十分敏感！

# 自定义添加的替换脚本至此止
    mytext = mytext.replace("0X","")
    return mytext

#%%
for filename in glob.glob('col.txt'):
    fopen = open(filename, 'r', encoding='utf8',errors='ignore')
    w_str=""
    for line in fopen:
        line = mysub(line)
        w_str = w_str + line
#        print(w_str)
    wopen = open(filename,'w', encoding='utf8', errors='ignore')
    wopen.write(w_str)
    wopen.close()

#%%




